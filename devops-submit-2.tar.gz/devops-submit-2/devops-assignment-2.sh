
# Instructions:

######
# In the folder containing your git clone from my github repo last week,

# Please do a `git pull origin main` to update with new content in my github repo.

# You should see `devops-sublime-2.tar.gz` assignment.

# copy it to  ~/Documents using `cp`

# cd to  ~/Documents and extract`devops-sublime-2.tar.gz` using `tar -xf`

# cd in to the `devops-sublime-2` folder

# Open the `devops-assignment-2.sh` file to begin:
#######



#!/bin/bash
echo "Creating heredoc.sh and teedoc.sh scripts using here"

# script-1 --- heredoc.sh
cat <<EOF > heredoc.sh
#!/bin/bash
echo "Current directory: $PWD"
sudo nginx -t
EOF

# script-2 --- teedoc.sh
tee teedoc.sh > /dev/null <<DOF
#!/bin/bash
mkdir -p production/index
touch production/index/file{1,2,3,4}.txt
DOF

echo -e "SETUP\v SUCCESSFULLY\v COMPLETED!!"




# QUESTIONS

1. a. Create the bash script above as `main.sh` and run it. 
   b. Describe what happens. Notice the `tee` command? What does it do?

2. Run the sub-scripts - script-1, script-2 - created by the bash script `main.sh` above.

3. Delete all that was created by `main.sh` using `rm` command.

4. Research and modify the `main.sh` bash script to display choices that prompt the user to enter 1 or 2 or 3. 
   For example:
    
    
    Welcome!.
    Would you like to create and run any/all of the following scripts:

    1. script-1
    2. script-2
    3. both

   Make sure the choice or choices of script will be created and executed when `main.sh` is executed.

5. Create a folder $USER-bash2 inside `devops-sublime-2`,
   Move ALL artifacts including devops-assignment-2.sh into $USER-bash2. 
   Compress $USER-bash2 folder to `devops-$USER-bash2.tar.gz`
   Move `devops-$USER-bash2.tar.gz` into the folder containing the contents you pushed to your repo last week.
   Now, 
   git add . 
   git commit -m "Adding Devops assignment 2"
   git push origin main

6. Share link to your github repo which you just updated.
   
   


